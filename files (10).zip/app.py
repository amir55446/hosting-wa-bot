#!/usr/bin/env python3
"""بوت الجيميلات v6.0 - النسخة الكاملة"""

import logging, json, re, os, random, string, httpx, io, asyncio
from datetime import datetime
from groq import Groq
from PIL import Image, ImageDraw, ImageFilter
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, filters, ContextTypes, ConversationHandler,
)

BOT_TOKEN        = "7772742859:AAGWIVRg6D6OP4Zgsr2C2MddAEGkXk_8Kdw"
ADMIN_ID         = 8217513989
CHANNEL_USERNAME = "@TESLA_TEAMI"
PROOFS_CHANNEL   = "@TESLA_PRO1"
GROQ_API_KEY     = "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"
DATA_FILE        = "bot_data.json"
MIN_WITHDRAW     = 5

(MAIN_MENU, DELIVER_GMAIL, CONFIRM_GMAIL, WITHDRAW_NUMBER,
 WITHDRAW_CONFIRM_NUM, WITHDRAW_NAME, ADD_CHANNEL, ADMIN_SEARCH,
 BALANCE_ADJUST, ADD_ADMIN) = range(10)

logging.basicConfig(format="%(asctime)s | %(levelname)s | %(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)
groq_client = Groq(api_key=GROQ_API_KEY)
GROQ_MODEL  = "llama-3.3-70b-versatile"

bot_config = {
    "names":[],"password":"","format_template":"","prices":"",
    "price_per_gmail":0,"channel":CHANNEL_USERNAME,"extra_channels":[],
    "bot_name":"بوت الجيميلات","welcome_msg":"👋 مرحباً {name}!\nاختر ما تريد:","developer":"@T_TSLA",
}

# ══════════════════════════════════════════════════════
# قاعدة البيانات
# ══════════════════════════════════════════════════════
def load_db():
    global bot_config
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE,"r",encoding="utf-8") as f:
                data=json.load(f)
            if "bot_config" in data: bot_config.update(data["bot_config"])
            logger.info(f"✅ تم تحميل البيانات: {len(data.get('users',{}))} مستخدم")
            return data
        except Exception as e: logger.error(f"load_db: {e}")
    return {"users":{},"banned_users":[],"blocked_bot":[],"delivered_gmails":[],
            "withdrawal_history":[],"gmails":[],"sub_admins":[]}

def save_db():
    try:
        db["bot_config"]=bot_config
        with open(DATA_FILE,"w",encoding="utf-8") as f: json.dump(db,f,ensure_ascii=False,indent=2)
    except Exception as e: logger.error(f"save_db: {e}")

db=load_db()
for k in ["users","banned_users","blocked_bot","delivered_gmails","withdrawal_history","gmails","sub_admins"]:
    db.setdefault(k,[] if k!="users" else {})

def get_user(uid):
    k=str(uid)
    if k not in db["users"]:
        db["users"][k]={"balance":0.0,"wallets":[],"first_name":"","username":"","joined":datetime.now().isoformat(),"gmails":0}
    return db["users"][k]

def add_balance(uid,amount):
    u=get_user(uid); u["balance"]=round(u["balance"]+amount,2); save_db()

def get_balance(uid): return get_user(uid).get("balance",0)
def is_banned(uid): return uid in db.get("banned_users",[])
def is_admin(uid): return uid==ADMIN_ID or uid in db.get("sub_admins",[])
def gen_id(): return ''.join(random.choices(string.ascii_lowercase+string.digits,k=8))
def mask_last4(number):
    n=re.sub(r'\D','',number)
    return n[:-4]+"****" if len(n)>4 else "****"

# ══════════════════════════════════════════════════════
# معالجة الصور — تشويش (Blur) على الرقم
# ══════════════════════════════════════════════════════
def mask_phone_in_image(image_bytes, known_number=""):
    known_clean=re.sub(r'\D','',known_number) if known_number else ""
    phone_pat=re.compile(r'01[0-9]{8,9}')

    def _digits_match(digits):
        if len(digits)<5: return False
        if phone_pat.search(digits): return True
        if known_clean and len(known_clean)>=6:
            if known_clean in digits or digits in known_clean: return True
            if len(digits)>=6 and known_clean.endswith(digits[-6:]): return True
        return False

    try:
        import pytesseract
        img=Image.open(io.BytesIO(image_bytes)).convert("RGB")
        boxes=[]
        for lang in ("eng","ara+eng"):
            try:
                data=pytesseract.image_to_data(img,output_type=pytesseract.Output.DICT,lang=lang)
            except Exception as e:
                logger.warning(f"OCR lang={lang} فشلت: {e}")
                continue

            n=len(data['text'])
            # محاولة 1: مطابقة كل كلمة لوحدها
            for i in range(n):
                digits=re.sub(r'\D','',data['text'][i])
                if _digits_match(digits):
                    x,y,w,h=data['left'][i],data['top'][i],data['width'][i],data['height'][i]
                    if w>0 and h>0: boxes.append((x,y,w,h))

            # محاولة 2: لو الرقم اتقسم بالغلط على أكتر من كلمة بنفس السطر
            if not boxes:
                lines={}
                for i in range(n):
                    key=(data['block_num'][i],data['par_num'][i],data['line_num'][i])
                    lines.setdefault(key,[]).append(i)
                for idxs in lines.values():
                    combined="".join(re.sub(r'\D','',data['text'][i]) for i in idxs)
                    if _digits_match(combined):
                        xs=[data['left'][i] for i in idxs]
                        ys=[data['top'][i] for i in idxs]
                        x2s=[data['left'][i]+data['width'][i] for i in idxs]
                        y2s=[data['top'][i]+data['height'][i] for i in idxs]
                        if xs: boxes.append((min(xs),min(ys),max(x2s)-min(xs),max(y2s)-min(ys)))

            if boxes: break  # لقينا الرقم، لا داعي لتجربة لغة تانية

        if not boxes:
            raise ValueError("OCR لم يجد الرقم في أي لغة")

        for (x,y,w,h) in boxes:
            pad=6
            box=(max(0,x-pad),max(0,y-pad),x+w+pad,y+h+pad)
            region=img.crop(box).filter(ImageFilter.GaussianBlur(radius=15))
            img.paste(region,box)
        out=io.BytesIO(); img.save(out,format='JPEG',quality=92)
        return out.getvalue(), True

    except Exception as e:
        logger.error(f"OCR mask error (سيُستخدم تشويش احتياطي محدد على سطر الرقم فقط): {e}")
        try:
            img=Image.open(io.BytesIO(image_bytes)).convert("RGB")
            w,h=img.size
            # منطقة احتياطية مضبوطة على سطر الرقم نفسه (أسفل سطر الاسم بقليل) بدل الصندوق كله
            box=(0,int(h*0.415),w,int(h*0.465))
            region=img.crop(box).filter(ImageFilter.GaussianBlur(radius=22))
            img.paste(region,box)
            out=io.BytesIO(); img.save(out,format='JPEG',quality=92)
            return out.getvalue(), False
        except: return image_bytes, False

# ══════════════════════════════════════════════════════
# AI - للأدمن فقط
# ══════════════════════════════════════════════════════
ADMIN_SYS=(
    "أنت مساعد ذكاء اصطناعي (sub-admin) لبوت جيميلات. لديك صلاحية كاملة، لكن رتبتك أقل من مالك البوت.\n"
    "ضع الأوامر بالصيغة: [[CMD:{\"action\":\"اسم\",...}]]\n"
    "الأوامر: broadcast|add_channel|remove_channel|set_names|set_password|set_format|"
    "set_prices|set_price_per_gmail|clear_names|ban_user|unban_user|set_welcome|set_bot_name\n"
    "قواعد: نفذ فوراً. تكلم بالعربي فقط.\nالبيانات:\n{config}"
)
ai_convs={}

def get_ai_resp(uid,msg):
    try:
        cfg=json.dumps(bot_config,ensure_ascii=False,indent=2)
        sys=ADMIN_SYS.replace("{config}",cfg)
        if uid not in ai_convs: ai_convs[uid]=[]
        msgs=[{"role":"system","content":sys}]+ai_convs[uid][-20:]+[{"role":"user","content":msg}]
        r=groq_client.chat.completions.create(model=GROQ_MODEL,messages=msgs,max_tokens=1000,temperature=0.7)
        reply=r.choices[0].message.content
        ai_convs[uid].append({"role":"user","content":msg})
        ai_convs[uid].append({"role":"assistant","content":reply})
        return reply
    except Exception as e:
        logger.error(f"Groq: {e}"); return "⚠️ خطأ في AI."

def parse_cmds(text):
    cmds=[]
    for m in re.findall(r'\[\[CMD:(.*?)\]\]',text,re.DOTALL):
        try: cmds.append(json.loads(m.strip()))
        except: pass
    return cmds,re.sub(r'\[\[CMD:.*?\]\]','',text,flags=re.DOTALL).strip()

async def exec_cmd(cmd,context):
    a=cmd.get("action","")
    if a=="broadcast":
        msg=cmd.get("message","")
        if not msg: return "⚠️ لا نص"
        ok=fail=0
        for uid in list(all_users):
            if uid==ADMIN_ID: continue
            try: await context.bot.send_message(uid,f"📢 إذاعة:\n\n{msg}"); ok+=1
            except: fail+=1
        return f"✅ إذاعة: ناجح {ok} | فاشل {fail}"
    elif a in("add_channel","remove_channel"):
        ch=cmd.get("channel","").strip()
        if not ch.startswith("@"): ch="@"+ch
        if a=="add_channel":
            if ch not in bot_config["extra_channels"] and ch!=bot_config["channel"]:
                bot_config["extra_channels"].append(ch); save_db(); return f"✅ أضيف: {ch}"
            return "⚠️ موجود مسبقاً"
        else:
            if ch in bot_config["extra_channels"]:
                bot_config["extra_channels"].remove(ch); save_db(); return f"✅ حُذف: {ch}"
            return "⚠️ غير موجود"
    elif a=="set_names":
        names=[n for n in cmd.get("names",[]) if n.strip()]
        bot_config["names"].extend(names); save_db(); return f"✅ {len(names)} اسم"
    elif a=="set_password": bot_config["password"]=cmd.get("password",""); save_db(); return "✅ باسورد"
    elif a=="set_format": bot_config["format_template"]=cmd.get("format",""); save_db(); return "✅ صيغة"
    elif a=="set_prices": bot_config["prices"]=cmd.get("prices",""); save_db(); return "✅ أسعار"
    elif a=="set_price_per_gmail":
        try: bot_config["price_per_gmail"]=float(cmd.get("price",0)); save_db(); return f"✅ {bot_config['price_per_gmail']} ج"
        except: return "⚠️ رقم غير صالح"
    elif a=="clear_names": n=len(bot_config["names"]); bot_config["names"]=[]; save_db(); return f"✅ مسح {n}"
    elif a=="ban_user":
        uid=cmd.get("user_id")
        if uid:
            if uid not in db["banned_users"]: db["banned_users"].append(uid); save_db()
            try: await context.bot.send_message(uid,"⛔️ محظور.")
            except: pass
            return f"✅ حظر {uid}"
        return "⚠️ معرف غير صالح"
    elif a=="unban_user":
        uid=cmd.get("user_id")
        if uid and uid in db["banned_users"]: db["banned_users"].remove(uid); save_db(); return f"✅ رفع حظر {uid}"
        return "⚠️ غير محظور"
    elif a=="set_welcome": bot_config["welcome_msg"]=cmd.get("message",""); save_db(); return "✅ ترحيب"
    elif a=="set_bot_name": bot_config["bot_name"]=cmd.get("name",""); save_db(); return "✅ اسم"
    else: return f"⚠️ غير معروف: {a}"

# ══════════════════════════════════════════════════════
# دوال مساعدة
# ══════════════════════════════════════════════════════
def validate_gmail(email):
    email=email.strip()
    if " " in email: return False,"❌ مسافات!"
    if not email.endswith("@gmail.com"): return False,"❌ يجب @gmail.com"
    if not re.match(r'^[a-zA-Z0-9._%+\-]+@gmail\.com$',email): return False,"❌ صيغة خاطئة"
    return True,"✅ صحيح"

async def check_subscription(uid,context):
    for ch in [bot_config["channel"]]+bot_config.get("extra_channels",[]):
        try:
            m=await context.bot.get_chat_member(ch,uid)
            if m.status not in ["member","administrator","creator"]: return False
        except: pass
    return True

async def verify_on_site(email):
    try:
        async with httpx.AsyncClient(timeout=15,verify=False) as c:
            r=await c.post("https://gmailver.com/",data={"email":email},
                headers={"User-Agent":"Mozilla/5.0"},follow_redirects=True)
            txt=r.text.lower()
            if any(w in txt for w in ["valid","exists","found","active"]): return True,"✅ موجود (gmailver)"
            if any(w in txt for w in ["invalid","not exist","not found"]): return False,"❌ غير موجود (gmailver)"
            return True,"⚠️ تم الفحص"
    except: return True,"⚠️ تعذر الاتصال"

def find_gmail_in_db(gmail_id):
    for g in db.get("gmails",[]):
        if g.get("id")==gmail_id: return g
    return None

def get_gmails_by_status(status):
    return [g for g in db.get("gmails",[]) if g.get("status")==status]

WALLET_NAMES={"vodafone":"فودافون كاش","etisalat":"اتصالات كاش","orange":"أورنج كاش"}
WALLET_EMOJIS={"vodafone":"📱","etisalat":"📡","orange":"🟠"}

all_users=set(int(k) for k in db.get("users",{}).keys())
pending_gmail={}
pending_reviews={}
pending_wdraw={}

# ══════════════════════════════════════════════════════
# Keyboards
# ══════════════════════════════════════════════════════
def B(text, callback_data=None, url=None, style="primary"):
    """دالة مساعدة لإنشاء زرار بلون: primary=أزرق, success=أخضر, danger=أحمر"""
    if url: return InlineKeyboardButton(text, url=url)
    return InlineKeyboardButton(text, callback_data=callback_data, style=style)

def main_kb(uid=None):
    bal=get_balance(uid) if uid else 0
    return InlineKeyboardMarkup([
        [B("📬 تسليم الجيميلات",          "deliver_gmail")],
        [B("📋 الجيميلات المطلوبة اليوم", "required_gmails", style="success")],
        [B("💰 أسعار الجيميلات",          "prices")],
        [B(f"💳 السحب | رصيدك: {bal} ج",  "withdraw_menu")],
        [B("👨‍💻 المطور",                   "developer", style="success")],
    ])

def required_kb():
    return InlineKeyboardMarkup([
        [B("🔤 أسماء الجيميلات",  "names_section")],
        [B("🔑 باسورد الجيميلات", "password_section")],
        [B("📐 صيغة الجيميلات",   "format_section")],
        [B("🔙 رجوع",              "back_main", style="danger")],
    ])

def names_kb():
    return InlineKeyboardMarkup([
        [B("👤 فردي",       "names_single"),
         B("👥 كل الأسماء", "names_all")],
        [B("🔙 رجوع",       "required_gmails", style="danger")],
    ])

def confirm_gmail_kb():
    return InlineKeyboardMarkup([
        [B("✅ تأكيد التسليم","confirm_deliver", style="success")],
        [B("✏️ تعديل",        "edit_gmail", style="primary")],
        [B("❌ إلغاء",         "cancel_deliver", style="danger")],
    ])

def sub_kb():
    chs=[bot_config["channel"]]+bot_config.get("extra_channels",[])
    btns=[[B(f"📢 {c}",url=f"https://t.me/{c.lstrip('@')}")] for c in chs]
    btns.append([B("🔄 تحقق","check_sub")])
    return InlineKeyboardMarkup(btns)

def back_kb(): return InlineKeyboardMarkup([[B("🔙 القائمة الرئيسية","back_main", style="danger")]])

def withdraw_kb(uid):
    u=get_user(uid); bal=u["balance"]; wallets=u.get("wallets",[])
    btns=[]
    if wallets and bal>=MIN_WITHDRAW:
        btns.append([B(f"💸 طلب سحب ({bal} ج)","withdraw_request")])
    btns+=[[B("📱 فودافون كاش","wallet_add_vodafone")],
           [B("📡 اتصالات كاش","wallet_add_etisalat")],
           [B("🟠 أورنج كاش",  "wallet_add_orange")],
           [B("🔙 رجوع",        "back_main", style="danger")]]
    return InlineKeyboardMarkup(btns)

def confirm_num_kb():
    return InlineKeyboardMarkup([[
        B("✅ تأكيد","confirm_wallet_num", style="success"),
        B("✏️ تعديل","edit_wallet_num", style="primary"),
    ]])

def wallets_kb(wallets):
    btns=[[B(
        f"{WALLET_EMOJIS.get(w['type'],'💳')} {WALLET_NAMES.get(w['type'],w['type'])} - {w['number']}",
        f"wvia_{i}")] for i,w in enumerate(wallets)]
    btns.append([B("🔙 رجوع","withdraw_menu", style="danger")])
    return InlineKeyboardMarkup(btns)

def confirm_wdraw_kb():
    return InlineKeyboardMarkup([[
        B("✅ تأكيد السحب","confirm_wdraw", style="success"),
        B("🔙 رجوع",        "withdraw_menu", style="danger"),
    ]])

def review_kb(rid):
    return InlineKeyboardMarkup([[
        B("✅ قبول","acc_"+rid, style="success"),
        B("❌ رفض", "rej_"+rid, style="danger"),
    ]])

def wdraw_review_kb(rid):
    """قبول (يطلب سكرين التحويل) أو رفض"""
    return InlineKeyboardMarkup([[
        B("✅ قبول","wacc_"+rid, style="success"),
        B("❌ رفض", "wrej_"+rid, style="danger"),
    ]])

def admin_kb(uid):
    total=len(db.get("users",{}))
    pending_count=len(get_gmails_by_status("pending"))
    acc_count=len(get_gmails_by_status("accepted"))
    rej_count=len(get_gmails_by_status("rejected"))
    rows=[
        [B("📝 أسماء",       "admin_add_names"),
         B("🔑 باسورد",      "admin_set_password")],
        [B("📐 صيغة",        "admin_set_format"),
         B("💰 أسعار",       "admin_set_prices")],
        [B("💵 سعر الجيميل", "admin_set_price_per_gmail")],
        [B(f"👥 المشتركين ({total})",   "admin_subscribers"),
         B("🔍 بحث مستخدم",             "admin_search_user")],
        [B(f"⏳ معلقة ({pending_count})","admin_gmails_pending"),
         B(f"✅ مقبولة ({acc_count})",   "admin_gmails_accepted", style="success")],
        [B(f"❌ مرفوضة ({rej_count})",   "admin_gmails_rejected", style="danger"),
         B("🔍 بحث جيميل",              "admin_search_gmail")],
        [B("📢 إدارة القنوات",           "admin_channels"),
         B("🗑️ مسح الأسماء",            "admin_clear_names", style="danger")],
        [B(f"📡 إذاعة ({len(all_users)})","admin_broadcast"),
         B("🤖 تحدث مع AI",              "admin_chat_ai")],
    ]
    if uid==ADMIN_ID:
        rows.append([B(f"👑 إدارة الأدمنز ({len(db.get('sub_admins',[]))})","admin_manage_admins")])
    return InlineKeyboardMarkup(rows)

def admin_back_kb(): return InlineKeyboardMarkup([[B("🔙 لوحة الأدمن","admin_back", style="danger")]])

def channels_kb():
    chs=[bot_config["channel"]]+bot_config.get("extra_channels",[])
    btns=[]
    for i,ch in enumerate(chs):
        if ch==bot_config["channel"]: btns.append([B(f"🔒 {ch}","noop")])
        else: btns.append([B(f"➕ {ch} ❌",f"rm_ch_{i}", style="danger")])
    btns.append([B("➕ إضافة قناة","admin_add_channel", style="success")])
    btns.append([B("🔙 رجوع","admin_back", style="danger")])
    return InlineKeyboardMarkup(btns)

def gmail_detail_kb(gid,status):
    btns=[]
    if status=="pending":
        btns.append([B("✅ قبول",f"gadm_acc_{gid}", style="success"),
                     B("❌ رفض",f"gadm_rej_{gid}", style="danger")])
    elif status=="rejected":
        btns.append([B("✅ تحويل لمقبول",f"gadm_acc_{gid}", style="success")])
    elif status=="accepted":
        btns.append([B("❌ تحويل لمرفوض",f"gadm_rej_{gid}", style="danger")])
    btns.append([B("🔙 رجوع","admin_back", style="danger")])
    return InlineKeyboardMarkup(btns)

# ══════════════════════════════════════════════════════
# Start
# ══════════════════════════════════════════════════════
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user=update.effective_user; uid=user.id
    all_users.add(uid)
    u=get_user(uid)
    is_new=u.get("first_name","")==""
    u["first_name"]=user.first_name or ""; u["username"]=user.username or ""; save_db()

    if is_banned(uid): await update.message.reply_text("⛔️ أنت محظور."); return MAIN_MENU

    if is_admin(uid):
        await update.message.reply_text(f"👋 أهلاً!\n🤖 {bot_config['bot_name']} جاهز\n👥 {len(db['users'])} مستخدم\nاستخدم /admin")
        await update.message.reply_text("اختر:",reply_markup=main_kb(uid)); return MAIN_MENU

    subscribed=await check_subscription(uid,context)
    if not subscribed:
        await update.message.reply_text(f"⛔️ مرحباً {user.first_name}!\nاشترك أولاً 👇",reply_markup=sub_kb()); return MAIN_MENU

    if is_new:
        uname=f"@{user.username}" if user.username else "بدون يوزرنيم"
        try:
            await context.bot.send_message(ADMIN_ID,
                f"🔔 عضو جديد!\n\n👤 <a href='tg://user?id={uid}'>{user.first_name}</a>\n🆔 <code>{uid}</code>\n📛 {uname}\n⏰ {datetime.now().strftime('%Y-%m-%d %H:%M')}",
                parse_mode="HTML")
        except: pass

    welcome=bot_config.get("welcome_msg","👋 مرحباً {name}!\nاختر ما تريد:").replace("{name}",user.first_name)
    await update.message.reply_text(welcome,reply_markup=main_kb(uid)); return MAIN_MENU

async def check_sub_cb(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q=update.callback_query; await q.answer(); uid=q.from_user.id; all_users.add(uid)
    if await check_subscription(uid,context):
        await q.edit_message_text("✅ تم التحقق!\n\nاختر من القائمة:",reply_markup=main_kb(uid)); return MAIN_MENU
    await q.answer("❌ لم تشترك بعد!",show_alert=True)

# ══════════════════════════════════════════════════════
# القائمة الرئيسية
# ══════════════════════════════════════════════════════
async def main_cb(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q=update.callback_query; await q.answer()
    data=q.data; uid=q.from_user.id; all_users.add(uid)

    if not is_admin(uid):
        if is_banned(uid): await q.edit_message_text("⛔️ أنت محظور."); return MAIN_MENU
        if not await check_subscription(uid,context):
            await q.edit_message_text("⛔️ اشترك أولاً!",reply_markup=sub_kb()); return MAIN_MENU

    if data=="back_main":
        await q.edit_message_text("🏠 القائمة الرئيسية",reply_markup=main_kb(uid)); return MAIN_MENU
    elif data=="deliver_gmail":
        await q.edit_message_text("📬 أرسل عنوان الجيميل:\nمثال: john.smith@gmail.com",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 رجوع",callback_data="back_main")]])); return DELIVER_GMAIL
    elif data=="required_gmails":
        await q.edit_message_text("📋 الجيميلات المطلوبة\n\nاختر القسم:",reply_markup=required_kb())
    elif data=="prices":
        await q.edit_message_text(f"💰 الأسعار\n\n{bot_config.get('prices') or 'لم يتم تحديد الأسعار بعد.'}",reply_markup=back_kb())
    elif data=="developer":
        await q.edit_message_text(f"👨‍💻 المطور\n\nالإصدار: 6.0\nالمطور: {bot_config.get('developer','@T_TSLA')}",reply_markup=back_kb())
    elif data=="names_section":
        c=len(bot_config["names"])
        if c==0: await q.edit_message_text("⚠️ لم يتم تحميل أسماء بعد.",reply_markup=back_kb()); return MAIN_MENU
        await q.edit_message_text(f"🔤 الأسماء المتاحة: {c}\n\nاختر:",reply_markup=names_kb())
    elif data=="names_single":
        if not bot_config["names"]: await q.answer("⚠️ لا أسماء!",show_alert=True); return MAIN_MENU
        await q.edit_message_text(f"👤 الاسم:\n\n{bot_config['names'][0]}\n\nاستخدمه في إنشاء الجيميل",reply_markup=back_kb())
    elif data=="names_all":
        if not bot_config["names"]: await q.answer("⚠️ لا أسماء!",show_alert=True); return MAIN_MENU
        txt="\n".join(f"• {n}" for n in bot_config["names"][:50])
        t=len(bot_config["names"])
        if t>50: txt+=f"\n... و{t-50} آخر"
        await q.edit_message_text(f"👥 الأسماء ({t}):\n\n{txt}",reply_markup=back_kb())
    elif data=="password_section":
        await q.edit_message_text(f"🔑 الباسورد:\n\n{bot_config.get('password') or 'لم يتم تحديد باسورد.'}",reply_markup=back_kb())
    elif data=="format_section":
        await q.edit_message_text(f"📐 الصيغة:\n\n{bot_config.get('format_template') or 'لم يتم تحديد صيغة.'}",reply_markup=back_kb())

    # ─── تأكيد الجيميل ───
    elif data=="confirm_deliver":
        gmail=pending_gmail.pop(uid,None)
        if not gmail: await q.answer("⚠️ خطأ!",show_alert=True); return MAIN_MENU
        uname=q.from_user.username or ""; fname=q.from_user.first_name
        rid=gen_id()
        pending_reviews[rid]={"uid":uid,"gmail":gmail,"username":uname,"first_name":fname}
        gmail_entry={"id":rid,"gmail":gmail,"uid":uid,"username":uname,"first_name":fname,
                     "status":"pending","submitted_at":datetime.now().isoformat(),"verify":{}}
        db["gmails"].append(gmail_entry); save_db()
        mention=f"<a href='tg://user?id={uid}'>{fname}</a>"
        try:
            await context.bot.send_message(ADMIN_ID,
                f"📧 جيميل جديد (قبل الفحص)\n\n📩 {gmail}\n👤 {mention} (@{uname})\n🆔 {uid}",
                parse_mode="HTML")
        except: pass
        await q.edit_message_text(f"⏳ تم إرسال الجيميل للأدمن وسيقوم بفحصه قريباً.\n\n📧 {gmail}",reply_markup=back_kb())
        context.application.create_task(_verify_and_notify(rid,gmail,uid,uname,fname,context))
        return MAIN_MENU

    elif data=="edit_gmail":
        pending_gmail.pop(uid,None)
        await q.edit_message_text("✏️ أرسل الجيميل الجديد:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 رجوع",callback_data="back_main")]])); return DELIVER_GMAIL
    elif data=="cancel_deliver":
        pending_gmail.pop(uid,None); await q.edit_message_text("❌ تم الإلغاء.",reply_markup=back_kb())

    # ─── قبول / رفض الجيميل ───
    elif data.startswith("acc_"):
        rid=data[4:]; rev=pending_reviews.pop(rid,None)
        if not rev: await q.answer("⚠️ انتهت الصلاحية!",show_alert=True); return MAIN_MENU
        price=float(bot_config.get("price_per_gmail",0))
        add_balance(rev["uid"],price)
        u=get_user(rev["uid"]); u["gmails"]=u.get("gmails",0)+1; save_db()
        for g in db["gmails"]:
            if g["id"]==rid: g["status"]="accepted"; g["reviewed_at"]=datetime.now().isoformat(); break
        db["delivered_gmails"].append({"gmail":rev["gmail"],"uid":rev["uid"],"username":rev["username"],"time":datetime.now().isoformat()})
        save_db()
        await q.edit_message_text(f"✅ تم القبول!\n\n📧 {rev['gmail']}\n💰 +{price} ج لـ @{rev['username']}")
        try: await context.bot.send_message(rev["uid"],f"🎉 تم قبول جيميلك!\n📧 {rev['gmail']}\n💰 +{price} ج\n💳 رصيدك: {get_balance(rev['uid'])} ج")
        except: pass
        try: await context.bot.send_message(PROOFS_CHANNEL,f"✅ تسليم ناجح!\n\n👤 @{rev['username']}\n⏰ {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        except: pass

    elif data.startswith("rej_"):
        rid=data[4:]; rev=pending_reviews.pop(rid,None)
        if not rev: await q.answer("⚠️ انتهت الصلاحية!",show_alert=True); return MAIN_MENU
        for g in db["gmails"]:
            if g["id"]==rid: g["status"]="rejected"; g["reviewed_at"]=datetime.now().isoformat(); break
        save_db()
        await q.edit_message_text(f"❌ تم الرفض: {rev['gmail']}")
        try: await context.bot.send_message(rev["uid"],f"❌ تم رفض جيميلك.\n📧 {rev['gmail']}")
        except: pass

    # ─── تغيير حالة جيميل من شاشة التفاصيل ───
    elif data.startswith("gadm_acc_") or data.startswith("gadm_rej_"):
        action_type="accept" if data.startswith("gadm_acc_") else "reject"
        gid=data.split("_",2)[-1]
        g_entry=find_gmail_in_db(gid)
        if not g_entry: await q.answer("⚠️ لم يُعثر على الجيميل!",show_alert=True); return MAIN_MENU
        old_status=g_entry["status"]; price=float(bot_config.get("price_per_gmail",0))
        if action_type=="accept" and old_status!="accepted":
            g_entry["status"]="accepted"; g_entry["reviewed_at"]=datetime.now().isoformat()
            add_balance(g_entry["uid"],price); save_db()
            try: await context.bot.send_message(g_entry["uid"],f"🎉 تم قبول جيميلك!\n📧 {g_entry['gmail']}\n💰 +{price} ج\n💳 رصيدك: {get_balance(g_entry['uid'])} ج")
            except: pass
            await q.edit_message_text(f"✅ تحويل لمقبول\n📧 {g_entry['gmail']}\n💰 +{price} ج",reply_markup=admin_back_kb())
        elif action_type=="reject" and old_status!="rejected":
            g_entry["status"]="rejected"; g_entry["reviewed_at"]=datetime.now().isoformat()
            if old_status=="accepted":
                u=get_user(g_entry["uid"]); u["balance"]=max(0,round(u["balance"]-price,2))
            save_db()
            try: await context.bot.send_message(g_entry["uid"],f"❌ تم رفض جيميلك.\n📧 {g_entry['gmail']}")
            except: pass
            await q.edit_message_text(f"❌ تحويل لمرفوض\n📧 {g_entry['gmail']}",reply_markup=admin_back_kb())
        else:
            await q.answer("⚠️ بالفعل في هذه الحالة!",show_alert=True)

    # ─── السحب ───
    elif data=="withdraw_menu":
        await q.edit_message_text(f"💳 قسم السحب\n\n💰 رصيدك: {get_balance(uid)} ج\n📌 الحد الأدنى: {MIN_WITHDRAW} ج\n\nاختر محفظتك:",reply_markup=withdraw_kb(uid))
    elif data.startswith("wallet_add_"):
        wtype=data[11:]; context.user_data["wallet_type"]=wtype
        await q.edit_message_text(f"{WALLET_EMOJIS.get(wtype,'💳')} إضافة {WALLET_NAMES.get(wtype,wtype)}\n\nأرسل رقم المحفظة:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 رجوع",callback_data="withdraw_menu")]])); return WITHDRAW_NUMBER
    elif data=="withdraw_request":
        u=get_user(uid); wallets=u.get("wallets",[])
        if not wallets: await q.edit_message_text("⚠️ لم تضف محفظة بعد.",reply_markup=withdraw_kb(uid)); return MAIN_MENU
        await q.edit_message_text(f"💸 طلب سحب\n\n💰 رصيدك: {u['balance']} ج\n\nاختر المحفظة:",reply_markup=wallets_kb(wallets))
    elif data.startswith("wvia_"):
        idx=int(data[5:]); u=get_user(uid); wallets=u.get("wallets",[])
        if idx>=len(wallets): await q.answer("⚠️ خطأ!",show_alert=True); return MAIN_MENU
        w=wallets[idx]; context.user_data["wdraw_wallet_idx"]=idx
        wname=WALLET_NAMES.get(w["type"],w["type"]); emj=WALLET_EMOJIS.get(w["type"],"💳")
        await q.edit_message_text(f"💸 تأكيد السحب\n\n💰 {u['balance']} ج\n{emj} {wname}\n📱 {w['number']}\n👤 {w.get('name','')}\n\nتأكيد؟",reply_markup=confirm_wdraw_kb())
    elif data=="confirm_wdraw":
        u=get_user(uid); idx=context.user_data.get("wdraw_wallet_idx",0)
        wallets=u.get("wallets",[]); bal=u["balance"]
        if bal<MIN_WITHDRAW: await q.answer(f"⚠️ رصيدك أقل من {MIN_WITHDRAW} ج!",show_alert=True); return MAIN_MENU
        w=wallets[idx]; rid=gen_id()
        pending_wdraw[rid]={"uid":uid,"amount":bal,"wallet":w,"username":q.from_user.username or "","first_name":q.from_user.first_name}
        wname=WALLET_NAMES.get(w["type"],w["type"]); emj=WALLET_EMOJIS.get(w["type"],"💳")
        fname=q.from_user.first_name; uname=q.from_user.username or "بدون يوزرنيم"
        try:
            await context.bot.send_message(ADMIN_ID,
                f"💸 طلب سحب!\n\n👤 <a href='tg://user?id={uid}'>{fname}</a> (@{uname})\n🆔 <code>{uid}</code>\n💰 {bal} ج\n{emj} {wname}\n📱 {w['number']}\n👤 {w.get('name','')}",
                parse_mode="HTML",reply_markup=wdraw_review_kb(rid))
        except: pass
        await q.edit_message_text(f"✅ تم إرسال طلب السحب!\n\n💰 {bal} ج\nسيتم معالجته قريباً.",reply_markup=back_kb())

    # ─── قبول السحب → يطلب سكرين ───
    elif data.startswith("wacc_"):
        rid=data[5:]; req=pending_wdraw.get(rid)
        if not req: await q.answer("⚠️ انتهت الصلاحية!",show_alert=True); return MAIN_MENU
        context.user_data["screenshot_rid"]=rid
        context.user_data["admin_action"]="send_screenshot"
        await q.edit_message_text(
            f"📸 تم قبول الطلب!\n\n💰 {req['amount']} ج\n👤 @{req.get('username','')}\n\n"
            f"أرسل الآن صورة (سكرين) إيصال التحويل:")

    elif data.startswith("wrej_"):
        rid=data[5:]; req=pending_wdraw.pop(rid,None)
        if not req: await q.answer("⚠️ انتهت الصلاحية!",show_alert=True); return MAIN_MENU
        await q.edit_message_text("❌ تم رفض طلب السحب.")
        try: await context.bot.send_message(req["uid"],f"❌ تم رفض طلب سحب {req['amount']} ج.")
        except: pass

    elif data=="confirm_wallet_num":
        num=context.user_data.get("wallet_number",""); wtype=context.user_data.get("wallet_type","")
        await q.edit_message_text(f"✅ الرقم: {num}\n\nأرسل الاسم المسجل في {WALLET_NAMES.get(wtype,wtype)}:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 رجوع",callback_data="withdraw_menu")]])); return WITHDRAW_NAME
    elif data=="edit_wallet_num":
        wtype=context.user_data.get("wallet_type","")
        await q.edit_message_text(f"{WALLET_EMOJIS.get(wtype,'💳')} أرسل الرقم من جديد:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 رجوع",callback_data="withdraw_menu")]])); return WITHDRAW_NUMBER

    elif data.startswith("rm_ch_"):
        idx=int(data[6:]); chs=[bot_config["channel"]]+bot_config.get("extra_channels",[])
        if 0<idx<len(chs): bot_config["extra_channels"].remove(chs[idx]); save_db(); await q.edit_message_text("✅ تمت الإزالة.",reply_markup=channels_kb())
        else: await q.answer("⚠️ لا يمكن حذف الرئيسية!",show_alert=True)

    elif data.startswith("ban_"):
        target=int(data[4:])
        if target not in db["banned_users"]: db["banned_users"].append(target); save_db()
        try: await context.bot.send_message(target,"⛔️ تم حظرك.")
        except: pass
        await q.edit_message_text(f"✅ تم حظر {target}.",reply_markup=admin_back_kb())
    elif data.startswith("unban_"):
        target=int(data[6:])
        if target in db["banned_users"]: db["banned_users"].remove(target); save_db()
        await q.edit_message_text(f"✅ رُفع الحظر عن {target}.",reply_markup=admin_back_kb())

    # ─── تعديل الرصيد ───
    elif data.startswith("adjbal_deduct_"):
        target=int(data[14:]); context.user_data["balance_adjust_target"]=target
        await q.edit_message_text(f"➖ خصم رصيد من {target}\n\nالرصيد الحالي: {get_balance(target)} ج\n\nأرسل المبلغ المطلوب خصمه:")
        return BALANCE_ADJUST
    elif data.startswith("adjbal_clear_"):
        target=int(data[13:]); u=get_user(target); old=u["balance"]; u["balance"]=0; save_db()
        await q.edit_message_text(f"✅ تم تصفية رصيد {target}\nكان: {old} ج ← الآن: 0 ج",reply_markup=admin_back_kb())
        try: await context.bot.send_message(target,"ℹ️ تم تصفية رصيدك من قبل الإدارة.")
        except: pass

    # ─── إدارة الأدمنز (مالك فقط) ───
    elif data=="admin_manage_admins":
        if uid!=ADMIN_ID: await q.answer("⛔️ للمالك فقط!",show_alert=True); return MAIN_MENU
        subs=db.get("sub_admins",[])
        txt=f"👑 إدارة الأدمنز\n\nالعدد: {len(subs)}\n\n"
        btns=[]
        for sid in subs:
            su=db.get("users",{}).get(str(sid),{})
            btns.append([InlineKeyboardButton(f"❌ {su.get('first_name','')} ({sid})",callback_data=f"rmadm_{sid}")])
        btns.append([InlineKeyboardButton("➕ إضافة أدمن",callback_data="admin_add_admin")])
        btns.append([InlineKeyboardButton("🔙 رجوع",callback_data="admin_back")])
        await q.edit_message_text(txt,reply_markup=InlineKeyboardMarkup(btns))
    elif data=="admin_add_admin":
        if uid!=ADMIN_ID: await q.answer("⛔️ للمالك فقط!",show_alert=True); return MAIN_MENU
        context.user_data["admin_action"]="add_admin"
        await q.edit_message_text("➕ أرسل آيدي أو يوزر المستخدم لرفعه أدمن:\nمثال: 123456789 أو @username",reply_markup=admin_back_kb())
        return ADD_ADMIN
    elif data.startswith("rmadm_"):
        if uid!=ADMIN_ID: await q.answer("⛔️ للمالك فقط!",show_alert=True); return MAIN_MENU
        target=int(data[6:])
        if target in db.get("sub_admins",[]): db["sub_admins"].remove(target); save_db()
        await q.edit_message_text(f"✅ تمت إزالة الأدمن {target}.",reply_markup=admin_back_kb())

    elif data=="noop": pass
    return MAIN_MENU

# ══════════════════════════════════════════════════════
# فحص الجيميل بالموقع + AI (بدون تسجيل دخول)
# ══════════════════════════════════════════════════════
async def _verify_and_notify(rid,gmail,uid,uname,fname,context):
    try:
        site_ok,site_msg=await verify_on_site(gmail)
        ai_ok=True; ai_msg=""
        fmt=bot_config.get("format_template","")
        if fmt:
            ai_r=get_ai_resp(ADMIN_ID,f"هل الجيميل '{gmail}' يتوافق مع الصيغة '{fmt}'؟ أجب بـ 'نعم' أو 'لا' مع سبب قصير.")
            ai_ok=any(w in (ai_r or "") for w in ["نعم","yes","مقبول","متوافق","صحيح"])
            ai_msg=(ai_r or "")[:200]
        for g in db["gmails"]:
            if g["id"]==rid:
                g["verify"]={"site_ok":site_ok,"site_msg":site_msg,"ai_ok":ai_ok}; break
        save_db()
        mention=f"<a href='tg://user?id={uid}'>{fname}</a>"
        msg=(f"📧 نتيجة الفحص\n\n📩 {gmail}\n👤 {mention} (@{uname})\n🆔 {uid}\n\n"
             f"🌐 gmailver.com: {site_msg}\n🤖 AI (صيغة): {'✅ متوافق' if ai_ok else '❌ غير متوافق'}")
        if ai_msg: msg+=f"\n💬 {ai_msg}"
        msg+=f"\n\n{'✅ مقبول' if (site_ok and ai_ok) else '⚠️ يحتاج مراجعة'} — اضغط:"
        await context.bot.send_message(ADMIN_ID,msg,parse_mode="HTML",reply_markup=review_kb(rid))
    except Exception as e:
        logger.error(f"verify_task: {e}")

# ══════════════════════════════════════════════════════
# Handlers المدخلات
# ══════════════════════════════════════════════════════
async def recv_gmail(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid=update.effective_user.id; email=update.message.text.strip()
    v,msg=validate_gmail(email)
    if not v: await update.message.reply_text(f"{msg}\n\nأرسل الجيميل مرة أخرى."); return DELIVER_GMAIL
    pending_gmail[uid]=email
    await update.message.reply_text(f"📧 الجيميل:\n{email}\n\nتأكيد؟",reply_markup=confirm_gmail_kb()); return CONFIRM_GMAIL

async def recv_wallet_num(update: Update, context: ContextTypes.DEFAULT_TYPE):
    num=update.message.text.strip()
    if not re.match(r'^0[0-9]{9,14}$',num): await update.message.reply_text("⚠️ رقم غير صالح. أرسل مرة أخرى:"); return WITHDRAW_NUMBER
    context.user_data["wallet_number"]=num
    await update.message.reply_text(f"📱 الرقم: {num}\n\nهل هذا صحيح؟",reply_markup=confirm_num_kb()); return WITHDRAW_CONFIRM_NUM

async def recv_wallet_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid=update.effective_user.id; name=update.message.text.strip()
    wtype=context.user_data.get("wallet_type",""); wnum=context.user_data.get("wallet_number","")
    u=get_user(uid); u["wallets"]=[w for w in u.get("wallets",[]) if w["type"]!=wtype]
    u["wallets"].append({"type":wtype,"number":wnum,"name":name}); save_db()
    await update.message.reply_text(
        f"✅ تم إضافة طريقة السحب بنجاح!\n\n{WALLET_EMOJIS.get(wtype,'💳')} {WALLET_NAMES.get(wtype,wtype)}\n📱 {wnum}\n👤 {name}",
        reply_markup=main_kb(uid)); return MAIN_MENU

async def recv_add_channel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id): return MAIN_MENU
    ch=update.message.text.strip()
    if not ch.startswith("@"): ch="@"+ch
    if ch not in bot_config["extra_channels"] and ch!=bot_config["channel"]:
        bot_config["extra_channels"].append(ch); save_db()
        await update.message.reply_text(f"✅ تمت الإضافة: {ch}",reply_markup=channels_kb())
    else:
        await update.message.reply_text(f"⚠️ {ch} مضافة مسبقاً.",reply_markup=channels_kb())
    return MAIN_MENU

async def recv_balance_adjust(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id): return MAIN_MENU
    target=context.user_data.get("balance_adjust_target")
    try: amount=float(update.message.text.strip())
    except: await update.message.reply_text("⚠️ أرسل رقم صحيح."); return BALANCE_ADJUST
    u=get_user(target); old=u["balance"]; u["balance"]=max(0,round(u["balance"]-amount,2)); save_db()
    await update.message.reply_text(f"✅ تم خصم {amount} ج من {target}\nكان: {old} ج ← الآن: {u['balance']} ج")
    try: await context.bot.send_message(target,f"ℹ️ تم خصم {amount} ج من رصيدك.\n💳 رصيدك الحالي: {u['balance']} ج")
    except: pass
    context.user_data["balance_adjust_target"]=None
    return MAIN_MENU

async def recv_add_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id!=ADMIN_ID: return MAIN_MENU
    txt=update.message.text.strip(); target_uid=None
    if txt.startswith("@"):
        uname=txt[1:].lower()
        for uid_s,u in db.get("users",{}).items():
            if u.get("username","").lower()==uname: target_uid=int(uid_s); break
    elif txt.isdigit(): target_uid=int(txt)
    if not target_uid:
        await update.message.reply_text("⚠️ لم يُعثر على المستخدم (يجب أن يكون استخدم البوت من قبل).",reply_markup=admin_back_kb())
    else:
        if target_uid not in db["sub_admins"]:
            db["sub_admins"].append(target_uid); save_db()
            await update.message.reply_text(f"✅ تم رفع {target_uid} كأدمن في البوت!",reply_markup=admin_back_kb())
            try: await context.bot.send_message(target_uid,"🎉 تم ترقيتك لتصبح أدمن في البوت! استخدم /admin")
            except: pass
        else:
            await update.message.reply_text("⚠️ هذا المستخدم أدمن مسبقاً.",reply_markup=admin_back_kb())
    context.user_data["admin_action"]=None
    return MAIN_MENU

async def recv_admin_search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id): return MAIN_MENU
    query=update.message.text.strip()
    search_type=context.user_data.get("search_type","user")
    context.user_data["admin_action"]=None

    if search_type=="gmail":
        results=[g for g in db.get("gmails",[]) if query.lower() in g.get("gmail","").lower()]
        if not results:
            await update.message.reply_text(f"🔍 لم يُعثر على '{query}'",reply_markup=admin_back_kb()); return MAIN_MENU
        txt=f"🔍 نتائج البحث عن '{query}':\n\n"
        btns=[]
        for g in results[:10]:
            se={"pending":"⏳","accepted":"✅","rejected":"❌"}.get(g["status"],"❓")
            txt+=f"{se} {g['gmail']}\n   👤 @{g.get('username','')} | 🆔 {g.get('uid','')}\n\n"
            btns.append([InlineKeyboardButton(f"{se} {g['gmail'][:30]}",callback_data=f"gadm_view_{g['id']}")])
        btns.append([InlineKeyboardButton("🔙 رجوع",callback_data="admin_back")])
        await update.message.reply_text(txt,reply_markup=InlineKeyboardMarkup(btns))
    else:
        found_uid=None; found_user=None
        if query.startswith("@"):
            uname=query[1:].lower()
            for uid_s,u in db.get("users",{}).items():
                if u.get("username","").lower()==uname: found_uid=int(uid_s); found_user=u; break
        elif query.isdigit():
            found_uid=int(query); found_user=db.get("users",{}).get(query)
        if not found_user:
            await update.message.reply_text(f"🔍 لم يُعثر على '{query}'",reply_markup=admin_back_kb()); return MAIN_MENU
        user_gmails=[g for g in db.get("gmails",[]) if g.get("uid")==found_uid]
        acc=sum(1 for g in user_gmails if g["status"]=="accepted")
        rej=sum(1 for g in user_gmails if g["status"]=="rejected")
        pend=sum(1 for g in user_gmails if g["status"]=="pending")
        is_ban=found_uid in db.get("banned_users",[])
        txt=(f"👤 ملف المستخدم\n\nالاسم: {found_user.get('first_name','')}\n"
             f"اليوزر: @{found_user.get('username','')}\nالآيدي: {found_uid}\n"
             f"الحالة: {'🚫 محظور' if is_ban else '✅ نشط'}\n\n💰 الرصيد: {found_user.get('balance',0)} ج\n"
             f"📊 الجيميلات:\n   ✅ مقبولة: {acc}\n   ❌ مرفوضة: {rej}\n   ⏳ معلقة: {pend}\n")
        ban_btn=InlineKeyboardButton(f"🚫 حظر {found_uid}",callback_data=f"ban_{found_uid}") if not is_ban \
               else InlineKeyboardButton(f"🔓 رفع الحظر",callback_data=f"unban_{found_uid}")
        btns=[[ban_btn],
              [InlineKeyboardButton("➖ خصم رصيد",callback_data=f"adjbal_deduct_{found_uid}"),
               InlineKeyboardButton("🗑 تصفية الرصيد",callback_data=f"adjbal_clear_{found_uid}")],
              [InlineKeyboardButton("🔙 رجوع",callback_data="admin_back")]]
        await update.message.reply_text(txt,reply_markup=InlineKeyboardMarkup(btns))
    return MAIN_MENU

# ══════════════════════════════════════════════════════
# لوحة الأدمن
# ══════════════════════════════════════════════════════
async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id): await update.message.reply_text("⛔️ غير مصرح!"); return
    context.user_data["admin_action"]=None
    uid=update.effective_user.id
    await update.message.reply_text(
        f"👑 لوحة التحكم\n\n👥 {len(db['users'])} مستخدم | 🚫 {len(db.get('banned_users',[]))} محظور\n"
        f"📧 {len(db.get('delivered_gmails',[]))} جيميل مسلم\n\nاختر:",
        reply_markup=admin_kb(uid))

async def admin_cb(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q=update.callback_query; await q.answer()
    uid=q.from_user.id
    if not is_admin(uid): await q.answer("⛔️ غير مصرح!",show_alert=True); return
    data=q.data

    if data=="admin_back":
        context.user_data["admin_action"]=None
        await q.edit_message_text(f"👑 لوحة التحكم\n\n👥 {len(db['users'])} | 📧 {len(db.get('delivered_gmails',[]))}\n\nاختر:",reply_markup=admin_kb(uid))
    elif data=="admin_add_names": context.user_data["admin_action"]="add_names"; await q.edit_message_text("📝 أرسل الأسماء (كل اسم في سطر):",reply_markup=admin_back_kb())
    elif data=="admin_set_password": context.user_data["admin_action"]="set_password"; await q.edit_message_text("🔑 أرسل الباسورد الجديد:",reply_markup=admin_back_kb())
    elif data=="admin_set_format": context.user_data["admin_action"]="set_format"; await q.edit_message_text("📐 أرسل الصيغة المطلوبة:",reply_markup=admin_back_kb())
    elif data=="admin_set_prices": context.user_data["admin_action"]="set_prices"; await q.edit_message_text("💰 أرسل جدول الأسعار:",reply_markup=admin_back_kb())
    elif data=="admin_set_price_per_gmail":
        context.user_data["admin_action"]="set_price_per_gmail"
        await q.edit_message_text(f"💵 السعر الحالي: {bot_config['price_per_gmail']} ج\n\nأرسل السعر الجديد:",reply_markup=admin_back_kb())
    elif data=="admin_view_delivered":
        gmails=db.get("delivered_gmails",[])
        txt=f"📊 الجيميلات المسلمة ({len(gmails)}):\n\n"
        for i,g in enumerate(gmails[-15:],1): txt+=f"{i}. {g.get('gmail','')} - @{g.get('username','')}\n"
        await q.edit_message_text(txt or "لا يوجد.",reply_markup=admin_back_kb())
    elif data=="admin_clear_names":
        n=len(bot_config["names"]); bot_config["names"]=[]; save_db()
        await q.edit_message_text(f"✅ مسح {n} اسم.",reply_markup=admin_back_kb())
    elif data=="admin_broadcast":
        context.user_data["admin_action"]="broadcast"
        await q.edit_message_text(
            f"📡 إذاعة للكل\n\n👥 {len(all_users)} مستخدم\n\n"
            f"أرسل أي رسالة (نص / صورة / فيديو / ستيكر) وسيتم تحويلها للكل\n"
            f"بدون ظهور اسمك، مع الحفاظ على الإيموجي المميز ✨",
            reply_markup=admin_back_kb())
    elif data=="admin_chat_ai":
        context.user_data["admin_action"]="chat_ai"
        await q.edit_message_text("🤖 AI (Sub-Admin)\n\nأرسل أوامرك:\n• 'ابعت إذاعة: نص'\n• 'أضف قناة @ch'\n• 'سعر الجيميل 8 جنيه'\n• 'احظر 123456'\n\nأرسل /admin للرجوع.",reply_markup=admin_back_kb())
    elif data=="admin_channels":
        await q.edit_message_text(f"📢 القنوات\nالرئيسية: {bot_config['channel']}\nإضافية: {len(bot_config['extra_channels'])}",reply_markup=channels_kb())
    elif data=="admin_add_channel":
        context.user_data["admin_action"]="add_channel_direct"
        await q.edit_message_text("📢 أرسل يوزرنيم القناة:\nمثال: @mychannel",reply_markup=admin_back_kb()); return ADD_CHANNEL
    elif data=="admin_search_user":
        context.user_data["admin_action"]="search"; context.user_data["search_type"]="user"
        await q.edit_message_text("🔍 بحث عن مستخدم\n\nأرسل الآيدي أو اليوزر (@username أو 123456):",reply_markup=admin_back_kb()); return ADMIN_SEARCH
    elif data=="admin_search_gmail":
        context.user_data["admin_action"]="search"; context.user_data["search_type"]="gmail"
        await q.edit_message_text("🔍 بحث عن جيميل\n\nأرسل جزءاً من عنوان الجيميل:",reply_markup=admin_back_kb()); return ADMIN_SEARCH
    elif data=="admin_gmails_pending": await _show_gmails_list(q,get_gmails_by_status("pending"),"⏳ الجيميلات المعلقة")
    elif data=="admin_gmails_accepted": await _show_gmails_list(q,get_gmails_by_status("accepted"),"✅ الجيميلات المقبولة")
    elif data=="admin_gmails_rejected": await _show_gmails_list(q,get_gmails_by_status("rejected"),"❌ الجيميلات المرفوضة")
    elif data=="admin_subscribers":
        total=len(db.get("users",{})); banned=len(db.get("banned_users",[])); blocked=len(db.get("blocked_bot",[]))
        txt=(f"👥 إحصائيات المشتركين\n\n📊 الإجمالي: {total}\n✅ نشطون: {total-blocked-banned}\n🚫 محظورون: {banned}\n❌ حظروا البوت: {blocked}\n\n─────\nآخر 10 مستخدمين:\n")
        for uid_s,u in list(db.get("users",{}).items())[-10:]:
            star="🚫" if int(uid_s) in db.get("banned_users",[]) else "✅"
            txt+=f"{star} {u.get('first_name','')} (@{u.get('username','')}) | {u.get('balance',0)}ج | {uid_s}\n"
        txt+="\n💡 /ban [ID] أو /unban [ID]"
        await q.edit_message_text(txt,reply_markup=admin_back_kb())
    elif data.startswith("gadm_view_"):
        gid=data[10:]; g=find_gmail_in_db(gid)
        if not g: await q.answer("⚠️ لم يُعثر!",show_alert=True); return
        se={"pending":"⏳","accepted":"✅","rejected":"❌"}.get(g["status"],"❓")
        v=g.get("verify",{})
        txt=(f"{se} تفاصيل الجيميل\n\n📩 {g['gmail']}\n👤 @{g.get('username','')}\n🆔 {g.get('uid','')}\n"
             f"📅 {g.get('submitted_at','')[:16]}\nالحالة: {g['status']}\n\n"
             f"🌐 gmailver: {'✅' if v.get('site_ok') else '❌'}\n🤖 AI: {'✅' if v.get('ai_ok') else '❌'}")
        await q.edit_message_text(txt,reply_markup=gmail_detail_kb(gid,g["status"]))

async def _show_gmails_list(q,gmails,title):
    if not gmails:
        await q.edit_message_text(f"{title}\n\nلا توجد جيميلات.",reply_markup=admin_back_kb()); return
    txt=f"{title} ({len(gmails)}):\n\n"
    btns=[]
    for g in gmails[-15:]:
        se={"pending":"⏳","accepted":"✅","rejected":"❌"}.get(g["status"],"❓")
        txt+=f"{se} {g['gmail']}\n   👤 @{g.get('username','')} | {g.get('submitted_at','')[:10]}\n\n"
        btns.append([InlineKeyboardButton(f"{se} {g['gmail'][:35]}",callback_data=f"gadm_view_{g['id']}")])
    btns.append([InlineKeyboardButton("🔙 رجوع",callback_data="admin_back")])
    await q.edit_message_text(txt,reply_markup=InlineKeyboardMarkup(btns))

# ══════════════════════════════════════════════════════
# الإذاعة عبر copy_message (تحافظ على كل الفورمات بما فيها الإيموجي المميز)
# ══════════════════════════════════════════════════════
async def _do_broadcast_copy(update, context):
    if not all_users:
        await update.message.reply_text("⚠️ لا يوجد مستخدمين."); context.user_data["admin_action"]=None; return
    await update.message.reply_text(f"📡 جارٍ الإرسال لـ {len(all_users)} مستخدم...")
    ok=fail=0
    src_chat=update.effective_chat.id
    msg_id=update.message.message_id
    for uid in list(all_users):
        try:
            await context.bot.copy_message(chat_id=uid,from_chat_id=src_chat,message_id=msg_id)
            ok+=1
        except Exception as e:
            fail+=1
            if "bot was blocked" in str(e).lower():
                if uid not in db["blocked_bot"]: db["blocked_bot"].append(uid); save_db()
    await update.message.reply_text(f"✅ اكتملت!\n✅ ناجح: {ok} | ❌ فاشل: {fail}")
    context.user_data["admin_action"]=None

# ══════════════════════════════════════════════════════
# معالجة سكرين تحويل السحب
# ══════════════════════════════════════════════════════
async def _process_withdrawal_screenshot(update, context):
    rid=context.user_data.get("screenshot_rid")
    req=pending_wdraw.get(rid)
    if not req: await update.message.reply_text("⚠️ انتهت صلاحية الطلب!"); return
    await update.message.reply_text("⏳ جارٍ معالجة الصورة وإرسالها...")

    photo=update.message.photo[-1]
    photo_file=await photo.get_file()
    img_bytes=bytes(await photo_file.download_as_bytearray())
    wallet_num=req["wallet"].get("number","")
    masked_bytes,_=mask_phone_in_image(img_bytes,wallet_num)

    w=req["wallet"]; wname=WALLET_NAMES.get(w["type"],w["type"])
    uname=req.get("username","") or "بدون يوزرنيم"
    amount=req["amount"]

    proofs_caption=f"تم التسليم ✅\nللمستخدم @{uname}\nالرقم {mask_last4(w['number'])}"
    user_caption=f"✅ تم التحويل بنجاح!\n\n💰 المبلغ: {amount} ج\n📱 عبر: {wname}\n\nشكراً لك 🎉"

    # للمستخدم: السكرين الأصلي بدون أي تعديل
    try: await context.bot.send_photo(req["uid"],photo=img_bytes,caption=user_caption)
    except Exception as e: logger.error(f"send to user: {e}")

    # لقناة الإثباتات: السكرين مع تشويش الرقم + وضع Spoiler في تليجرام
    try:
        await context.bot.send_photo(PROOFS_CHANNEL,photo=masked_bytes,caption=proofs_caption,has_spoiler=True)
    except Exception as e: logger.error(f"proofs: {e}")

    u=get_user(req["uid"]); u["balance"]=0
    db["withdrawal_history"].append({"uid":req["uid"],"amount":amount,"wallet":req["wallet"],"time":datetime.now().isoformat()})
    save_db()
    pending_wdraw.pop(rid,None)
    context.user_data["admin_action"]=None
    context.user_data.pop("screenshot_rid",None)
    await update.message.reply_text("✅ تم الإرسال للمستخدم ونشره في قناة الإثباتات!")

# ══════════════════════════════════════════════════════
# المعالج الموحّد لرسائل الأدمن (كل أنواع المحتوى)
# ══════════════════════════════════════════════════════
async def admin_universal_msg(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid=update.effective_user.id
    if not is_admin(uid): return await user_msg(update,context)

    action=context.user_data.get("admin_action")

    # ── الإذاعة (أي نوع محتوى) ──
    if action=="broadcast":
        await _do_broadcast_copy(update,context); return

    # ── سكرين تحويل السحب ──
    if action=="send_screenshot" and update.message.photo:
        await _process_withdrawal_screenshot(update,context); return

    if not update.message.text:
        await update.message.reply_text("⚠️ لا يوجد إجراء معلق لهذا النوع من الملفات."); return

    txt=update.message.text.strip()

    if action=="add_names":
        names=[n.strip() for n in txt.split("\n") if n.strip()]
        bot_config["names"].extend(names); save_db()
        await update.message.reply_text(f"✅ {len(names)} اسم! الإجمالي: {len(bot_config['names'])}")
        context.user_data["admin_action"]=None
    elif action=="set_password": bot_config["password"]=txt; save_db(); await update.message.reply_text("✅ تم!"); context.user_data["admin_action"]=None
    elif action=="set_format": bot_config["format_template"]=txt; save_db(); await update.message.reply_text("✅ تم!"); context.user_data["admin_action"]=None
    elif action=="set_prices": bot_config["prices"]=txt; save_db(); await update.message.reply_text("✅ تم!"); context.user_data["admin_action"]=None
    elif action=="set_price_per_gmail":
        try: bot_config["price_per_gmail"]=float(txt); save_db(); await update.message.reply_text(f"✅ {bot_config['price_per_gmail']} ج")
        except: await update.message.reply_text("⚠️ أرسل رقم فقط.")
        context.user_data["admin_action"]=None
    elif action=="add_channel_direct":
        ch=txt if txt.startswith("@") else "@"+txt
        if ch not in bot_config["extra_channels"] and ch!=bot_config["channel"]:
            bot_config["extra_channels"].append(ch); save_db(); await update.message.reply_text(f"✅ أُضيف: {ch}",reply_markup=channels_kb())
        else: await update.message.reply_text("⚠️ موجود.",reply_markup=channels_kb())
        context.user_data["admin_action"]=None
    elif action=="search": await recv_admin_search(update,context)
    elif action=="add_admin": await recv_add_admin(update,context)
    else:
        ai_raw=get_ai_resp(ADMIN_ID,txt)
        cmds,clean=parse_cmds(ai_raw or "")
        results=[]
        for cmd in cmds: r=await exec_cmd(cmd,context); results.append(r); logger.info(f"AI CMD: {cmd}→{r}")
        parts=[]
        if clean: parts.append(f"🤖 {clean}")
        if results: parts.append("─"*20+"\n⚙️ منفذ:\n"+"\n".join(results))
        await update.message.reply_text("\n".join(parts) if parts else "🤖 تم.")

async def ban_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id): return
    try:
        target=int(context.args[0])
        if target not in db["banned_users"]: db["banned_users"].append(target); save_db()
        try: await context.bot.send_message(target,"⛔️ تم حظرك.")
        except: pass
        await update.message.reply_text(f"✅ تم حظر {target}.")
    except: await update.message.reply_text("الاستخدام: /ban [user_id]")

async def unban_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id): return
    try:
        target=int(context.args[0])
        if target in db["banned_users"]: db["banned_users"].remove(target); save_db()
        await update.message.reply_text(f"✅ رُفع الحظر عن {target}.")
    except: await update.message.reply_text("الاستخدام: /unban [user_id]")

async def user_msg(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid=update.effective_user.id; all_users.add(uid)
    if is_banned(uid): await update.message.reply_text("⛔️ أنت محظور."); return
    if not await check_subscription(uid,context): await update.message.reply_text("⛔️ اشترك أولاً!",reply_markup=sub_kb()); return
    await update.message.reply_text("اختر من القائمة:",reply_markup=main_kb(uid))

# ══════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════
def main():
    # ── إصلاح توافق Python 3.14: إنشاء event loop يدوياً ──
    try:
        asyncio.get_event_loop()
    except RuntimeError:
        asyncio.set_event_loop(asyncio.new_event_loop())

    print(f"🚀 {bot_config['bot_name']} v6.0")
    print(f"👤 الأدمن: {ADMIN_ID} | 📢 {CHANNEL_USERNAME} | 📊 {PROOFS_CHANNEL}")
    print(f"💾 {len(db.get('users',{}))} مستخدم محمّل | {len(db.get('gmails',[]))} جيميل مسجل")
    app=Application.builder().token(BOT_TOKEN).build()
    conv=ConversationHandler(
        entry_points=[CommandHandler("start",start)],
        states={
            MAIN_MENU:[
                CallbackQueryHandler(check_sub_cb,pattern="^check_sub$"),
                CallbackQueryHandler(admin_cb,pattern="^admin_"),
                CallbackQueryHandler(main_cb),
                MessageHandler(filters.ALL & ~filters.COMMAND,admin_universal_msg),
            ],
            DELIVER_GMAIL:[
                MessageHandler(filters.TEXT & ~filters.COMMAND,recv_gmail),
                CallbackQueryHandler(main_cb,pattern="^back_main$"),
            ],
            CONFIRM_GMAIL:[ CallbackQueryHandler(main_cb) ],
            WITHDRAW_NUMBER:[
                MessageHandler(filters.TEXT & ~filters.COMMAND,recv_wallet_num),
                CallbackQueryHandler(main_cb,pattern="^withdraw_menu$"),
            ],
            WITHDRAW_CONFIRM_NUM:[ CallbackQueryHandler(main_cb,pattern="^(confirm_wallet_num|edit_wallet_num)$") ],
            WITHDRAW_NAME:[
                MessageHandler(filters.TEXT & ~filters.COMMAND,recv_wallet_name),
                CallbackQueryHandler(main_cb,pattern="^withdraw_menu$"),
            ],
            ADD_CHANNEL:[
                MessageHandler(filters.TEXT & ~filters.COMMAND,recv_add_channel),
                CallbackQueryHandler(admin_cb,pattern="^admin_back$"),
            ],
            ADMIN_SEARCH:[
                MessageHandler(filters.TEXT & ~filters.COMMAND,recv_admin_search),
                CallbackQueryHandler(admin_cb,pattern="^admin_back$"),
            ],
            BALANCE_ADJUST:[
                MessageHandler(filters.TEXT & ~filters.COMMAND,recv_balance_adjust),
                CallbackQueryHandler(admin_cb,pattern="^admin_back$"),
            ],
            ADD_ADMIN:[
                MessageHandler(filters.TEXT & ~filters.COMMAND,recv_add_admin),
                CallbackQueryHandler(admin_cb,pattern="^admin_back$"),
            ],
        },
        fallbacks=[CommandHandler("start",start),CommandHandler("admin",admin_panel)],
        per_user=True,per_chat=True,
    )
    app.add_handler(conv)
    app.add_handler(CommandHandler("admin",admin_panel))
    app.add_handler(CommandHandler("ban",ban_cmd))
    app.add_handler(CommandHandler("unban",unban_cmd))
    app.add_handler(CallbackQueryHandler(admin_cb,pattern="^admin_"))
    app.add_handler(CallbackQueryHandler(check_sub_cb,pattern="^check_sub$"))
    app.add_handler(CallbackQueryHandler(main_cb))
    app.add_handler(MessageHandler(filters.ALL & ~filters.COMMAND,admin_universal_msg))
    print("✅ البوت يعمل!")
    app.run_polling(drop_pending_updates=True)

if __name__=="__main__":
    main()
